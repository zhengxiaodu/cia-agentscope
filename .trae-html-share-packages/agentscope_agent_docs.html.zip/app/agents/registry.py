"""智能体注册表：加载配置，按智能体绑定的 skill 子集组装独立 Toolkit 并缓存。

设计要点：
- 系统启动时一次性加载所有可用 skill（按工作区机制装载）
- 每个智能体按其 skills 配置，从全量 skill 中筛选出子集，组装独立 Toolkit
- 这样不同智能体只能看到自己绑定的工具，实现职责隔离
"""
import logging
import os
from typing import Any, Dict, List, Optional

import yaml
from agentscope.agent import Agent, ContextConfig, ReActConfig
from agentscope.model import OpenAIChatModel
from agentscope.permission import PermissionContext, PermissionMode
from agentscope.state import AgentState
from agentscope.tool import Toolkit

from app.agents.base import AgentDefinition

logger = logging.getLogger(__name__)

def load_agent_definitions(config_path: str) -> List[AgentDefinition]:
    """从 agent_config.yml 加载所有智能体定义。"""
    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)
    raw_agents = config.get("agents", [])
    return [AgentDefinition(**a) for a in raw_agents]


class AgentRegistry:
    """智能体注册表：管理智能体定义、模型实例、按需创建带 skill 子集的 Agent。

    生命周期由 app.main lifespan 管理，单例存于 app.state。
    """

    def __init__(
        self,
        definitions: List[AgentDefinition],
        workspace: Any,
        all_tools: list,
        all_skills_meta: list,
        create_model_fn,
        extra_skill_names: Optional[List[str]] = None,
    ):
        """
        Args:
            definitions: 全部智能体定义
            workspace: 已初始化的工作区实例
            all_tools: 工作区内全部工具
            all_skills_meta: 工作区内全部 skill 元信息
            create_model_fn: 工厂函数，签名 create_model_fn() -> OpenAIChatModel，
                             每次调用返回新的模型实例（流式模型不可复用）
            extra_skill_names: 请求级附加技能名，union 到每个 agent 的绑定技能
                               （无论该 agent 是否绑定该技能，都会组装进其 Toolkit）
        """
        self._defs: Dict[str, AgentDefinition] = {d.id: d for d in definitions}
        self._workspace = workspace
        self._all_tools = all_tools
        self._all_skills_meta = all_skills_meta
        self._create_model_fn = create_model_fn
        # 请求级附加技能：组装 Toolkit 时与 agent 自身绑定技能取并集
        self._extra_skill_names = set(extra_skill_names or [])
        # 缓存每个智能体对应的 Toolkit（按 skill 子集组装），避免重复筛选
        self._toolkits: Dict[str, Toolkit] = {}

    @property
    def definitions(self) -> Dict[str, AgentDefinition]:
        return self._defs

    def get_definition(self, agent_id: str) -> Optional[AgentDefinition]:
        return self._defs.get(agent_id)

    def _build_toolkit_for(self, definition: AgentDefinition) -> Toolkit:
        """根据智能体绑定的 skill 列表，筛选工具子集组装 Toolkit。

        有效绑定技能 = agent 自身绑定技能 ∪ 请求级附加技能（extra_skill_names）。
        无任何绑定技能时返回空 Toolkit，即纯对话无工具。
        """
        # 有效绑定技能 = agent 自身绑定 ∪ 请求级附加技能
        bound_skill_names = set(definition.skills) | self._extra_skill_names
        if not bound_skill_names:
            return Toolkit(tools=[], skills_or_loaders=[])

        # 从 skill 元信息中筛选出绑定的 skill loader
        bound_loaders = []
        matched_names = set()
        for meta in self._all_skills_meta:
            # skill 元信息通常含 name 字段
            meta_name = getattr(meta, "name", None) or (
                meta.get("name") if isinstance(meta, dict) else None
            )
            if meta_name in bound_skill_names:
                bound_loaders.append(meta)
                matched_names.add(meta_name)

        # 请求了但 workspace 未装载的技能 → 记 warning 跳过
        missing = bound_skill_names - matched_names
        if missing:
            logger.warning(
                f"[AgentRegistry] 技能未在 workspace 装载，已跳过: {sorted(missing)}"
            )

        return Toolkit(tools=self._all_tools, skills_or_loaders=bound_loaders)

    def get_toolkit(self, agent_id: str) -> Optional[Toolkit]:
        """获取智能体的 Toolkit（带缓存）。"""
        definition = self._defs.get(agent_id)
        if definition is None:
            return None
        if agent_id not in self._toolkits:
            self._toolkits[agent_id] = self._build_toolkit_for(definition)
        return self._toolkits[agent_id]

    def create_agent(
        self,
        agent_id: str,
        session_id: Optional[str] = None,
        agent_state: Optional[AgentState] = None,
    ) -> Optional[Agent]:
        """创建一个 Agent 实例。

        Args:
            agent_id: 智能体 id
            session_id: 会话 id（用于 AgentState）
            agent_state: 已恢复的 AgentState（多轮上下文），优先使用；为 None 则新建

        Returns:
            Agent 实例，agent_id 不存在返回 None
        """
        definition = self._defs.get(agent_id)
        if definition is None:
            logger.warning(f"[AgentRegistry] 未知智能体: {agent_id}")
            return None

        # 每次创建新的模型实例（OpenAIChatModel 流式会话不可跨调用复用）
        model = self._create_model_fn()
        toolkit = self.get_toolkit(agent_id)

        # 状态：优先用传入的已恢复状态，否则新建
        if agent_state is None:
            agent_state = AgentState(
                session_id=session_id,
                permission_context=PermissionContext(mode=PermissionMode.BYPASS),
            )
        react_config = ReActConfig()
        react_config.max_iters = 200
        agent = Agent(
            name=definition.name,
            system_prompt=definition.system_prompt
            + f"\n注意当前工作区目录是/data/workspaces/{session_id}，你的技能文件已装载到该目录下，你只能在该目录下读/写/编辑文件，绝不允许操作目录以外的文件！"
            + "\n用户上传的文件不会出现在工作区目录中：其内容已解析并直接附在用户问题里，请直接阅读使用，不要尝试在工作区中查找用户附件。"
            + "\n当你生成文件时，生成的文件内容只要用户不做特殊说明应该以中文为主。"
            + "\n当用户要求修改文件时，必须生成新文件名（如添加版本号、时间戳或_modified后缀），严禁直接覆盖原文件，以防止数据丢失。"
            + "\n你仅允许通过系统内置的技能/工具获取外部信息（如联网搜索、知识库查询等），禁止自行使用curl、wget、requests或其他方式直接访问外部接口；禁止下载、安装额外的依赖包。若现有信息不足以解答用户问题，请如实告知、或尝试挖掘已有线索进行处理。",
            model=model,
            toolkit=toolkit,
            state=agent_state,
            context_config=ContextConfig(
                trigger_ratio=0.7,
                reserve_ratio=0.4,
                tool_result_limit=3000,
            ),
            react_config=react_config
        )
        return agent
