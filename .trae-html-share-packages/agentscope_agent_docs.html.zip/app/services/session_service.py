import logging
import uuid
from typing import Optional

from agentscope.state import AgentState

from app.models.session import (
    SessionMeta,
    SessionMessage,
    SessionDetailResponse,
    SessionFile,
    SessionUploadFile,
)

logger = logging.getLogger(__name__)


class SessionService:
    """会话生命周期管理"""

    def __init__(self, dao, upload_file_dao=None):
        """初始化会话服务。

        Args:
            dao: 会话 DAO（SessionDAO）。
            upload_file_dao: 可选注入的上传文件 DAO（供会话详情返回上传文件列表）。
        """
        self.dao = dao
        self.upload_file_dao = upload_file_dao

    async def get_or_create_session(self, session_id: Optional[str], user_id: str) -> str:
        """获取已有 session_id 或创建新会话。"""
        if session_id:
            return session_id
        return uuid.uuid4().hex

    async def load_agent_state(self, session_id: str, agent_id: str = "general_agent") -> Optional[dict]:
        """从 PostgreSQL 加载 AgentState 原始数据。"""
        return await self.dao.load_agent_state(session_id, agent_id)

    async def save_agent_state(self, session_id: str, user_id: str, agent_id: str, state_dict: dict) -> None:
        """将 AgentState dict 持久化到 PostgreSQL。"""
        await self.dao.save_agent_state(session_id, user_id, agent_id, state_dict)

    async def save_latest_trace_id(self, session_id: str, trace_id: str) -> None:
        """将最新 trace_id 保存到会话元信息。"""
        await self.dao.save_latest_trace_id(session_id, trace_id)

    async def mark_last_assistant_failed(self, session_id: str, user_id: str) -> None:
        """把该会话最新一条 assistant 消息标记为失败（用户中断时调用）。"""
        await self.dao.mark_last_assistant_failed(session_id, user_id)

    async def load_messages(self, session_id: str) -> list[dict]:
        """加载多智能体对话历史（纯消息列表形式）。"""
        return await self.dao.load_messages(session_id)

    async def append_messages(
        self, session_id: str, user_id: str, messages: list[dict]
    ) -> Optional[dict]:
        """向会话历史追加消息（用户输入 + 智能体输出）。

        Returns:
            {"user_message_id": int|None, "assistant_message_id": int|None}
            （MySQL DAO 返回；供上传文件回填 message_id 与生成文件关联 assistant 消息）。
        """
        return await self.dao.append_messages(session_id, user_id, messages)

    async def append_session_files(self, session_id: str, files: list[dict]) -> None:
        """持久化本轮生成的文件元信息（按 (session_id, path) UPSERT 去重）。"""
        await self.dao.append_session_files(session_id, files)

    async def load_session_files(self, session_id: str) -> list[dict]:
        """加载会话历史生成的文件元信息列表。"""
        return await self.dao.load_session_files(session_id)

    async def pin_session(self, user_id: str, session_id: str) -> None:
        """置顶会话。"""
        await self.dao.pin_session(user_id, session_id)

    async def unpin_session(self, user_id: str, session_id: str) -> None:
        """取消置顶会话。"""
        await self.dao.unpin_session(user_id, session_id)

    async def rename_session(
        self, user_id: str, session_id: str, name: str
    ) -> bool:
        """修改会话名称。返回 False 表示会话不存在。"""
        return await self.dao.rename_session(user_id, session_id, name)

    async def delete_session(self, user_id: str, session_id: str) -> bool:
        """删除会话。返回 False 表示会话不存在。"""
        if not await self.dao.session_exists(session_id):
            return False
        await self.dao.delete_session(session_id, user_id)
        return True

    async def delete_message(
        self, user_id: str, session_id: str, message_pair_id: str
    ) -> Optional[dict]:
        """删除会话中一轮消息（按 message_pair_id）；删空则整删会话。

        Returns:
            None: 会话不存在
            {"deleted": 0, "session_deleted": False}: 消息不存在
            {"deleted": n>0, "session_deleted": bool}: 删除成功
        Raises:
            PermissionError: 会话不属于当前用户（对齐 get_session_detail）。
        """
        meta = await self.dao.get_session_meta(session_id)
        if meta is None:
            return None
        if meta.get("user_id") != user_id:
            raise PermissionError("会话不属于当前用户")

        deleted = await self.dao.delete_messages_by_pair(session_id, message_pair_id)
        if deleted == 0:
            return {"deleted": 0, "session_deleted": False}

        # 删空（被删的是会话中唯一一轮消息）→ 整删会话（CASCADE 清理关联表）
        if await self.dao.count_messages(session_id) == 0:
            await self.dao.delete_session(session_id, user_id)
            return {"deleted": deleted, "session_deleted": True}
        return {"deleted": deleted, "session_deleted": False}

    async def list_user_sessions(
        self, user_id: str, page: int = 1, page_size: int = 15
    ) -> tuple[list[SessionMeta], list[SessionMeta], int]:
        """列出用户会话（分页），返回 (top_sessions, sessions, total)。

        total: 该用户非置顶会话总数（用于分页元数据）
        """
        raw_top, raw_list, total = await self.dao.list_user_sessions(
            user_id, page=page, page_size=page_size
        )
        return (
            [SessionMeta(**m) for m in raw_top],
            [SessionMeta(**m) for m in raw_list],
            total,
        )

    async def get_session_detail(
        self, session_id: str, user_id: str
    ) -> Optional[SessionDetailResponse]:
        """获取会话详情（含对话历史）。

        消息从 messages 表加载，不再从 AgentState 中提取。
        """
        meta = await self.dao.get_session_meta(session_id)
        if meta is None:
            return None

        if meta.get("user_id") != user_id:
            raise PermissionError("会话不属于当前用户")

        # 从 messages 表加载消息
        raw_messages = await self.dao.load_messages(session_id)
        messages = [SessionMessage(**m) for m in raw_messages]

        # 从 session_files 表加载历史生成的文件
        raw_files = await self.dao.load_session_files(session_id)
        files = [SessionFile(**f) for f in raw_files]

        # 加载该会话用户上传过的文件（含未被对话消费的记录）
        upload_files = []
        if self.upload_file_dao is not None:
            try:
                raw_uploads = await self.upload_file_dao.list_files_by_session(session_id)
                upload_files = [SessionUploadFile(**u) for u in raw_uploads]
            except Exception:
                logger.warning("[session_service] 加载会话上传文件失败", exc_info=True)

        return SessionDetailResponse(
            session_id=session_id,
            created_at=meta.get("created_at", ""),
            updated_at=meta.get("updated_at", ""),
            trace_id=meta.get("latest_trace_id"),
            messages=messages,
            files=files,
            upload_files=upload_files,
        )
